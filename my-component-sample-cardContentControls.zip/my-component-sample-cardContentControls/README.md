# sap-integration-card
UI Integration card
Right click on manifest en preview card.
